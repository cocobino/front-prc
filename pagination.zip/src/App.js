import React, {Component} from 'react';
import Pagination from './component/Pagination';

class App extends Component {

  render () {

     return( 
     <div className="App">
      <Pagination/>
    </div>
    );
  }
};

export default App;
