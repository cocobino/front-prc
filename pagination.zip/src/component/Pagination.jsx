import React, {Component} from 'react';
import {connect} from 'react-redux';
import './Pagination.css';

class Pagination extends Component {
    static getData() {
        // pageingUtil 에 필요한 정보를 받음
        return 'test';
    }

    setCurrentPage(type, recordCount, pageSize, currentPage) {
        let cur, maxPage = parseInt(recordCount/pageSize);
        switch(type) {
            case 'FIRST': cur=1; break;
            case 'PREV':  cur = currentPage -1 <=1 ? 1 : currentPage-1; break;
            case 'NEXT' : cur = currentPage+1 >= maxPage ? maxPage : currentPage+1;  break;
            case 'LAST' : cur = maxPage > 5 ? 5 : maxPage; break;
            case 'NUM' : cur = currentPage; break;
        }
        this.props.setCurrentPage(cur);
    }

    setPagesize(e) {
        this.props.setPagesize(Number(e.target.value));
    }

    renderDrawPageNumber(recordCount, pageSize, currentPage) {
        const pageNumber = parseInt(recordCount/pageSize);
        const pageTag =[];
        for(let i=1; pageNumber > 5 ? i<=5 : i<=pageNumber; i++) {
            pageTag.push(<li key={i}><button className={'numberBtn ' + (currentPage === i ? 'active' : '')} onClick={()=> this.setCurrentPage('NUM', '', '', i)}>{i}</button></li>);
        }
        return pageTag;
    }

    render() {
        const {pageUtil} = this.props;
        return (
        <div className="pagination">
            <div>
                <button className="btn-paging first" type="button" title="처음 페이지" onClick={() => this.setCurrentPage('FIRST', pageUtil['recordCount'], pageUtil['pageSize'], pageUtil['currentPage'])}></button>
                <button className="btn-paging prev" type="button" title="이전 페이지" onClick={() => this.setCurrentPage('PREV', pageUtil['recordCount'], pageUtil['pageSize'], pageUtil['currentPage'])}></button>
            </div>
            <ul className="number">
                {this.renderDrawPageNumber(pageUtil['recordCount'], pageUtil['pageSize'], pageUtil['currentPage'])}
            </ul>
            <div>
                <button className="btn-paging next" type="button" title="다음 페이지" onClick={() => this.setCurrentPage('NEXT', pageUtil['recordCount'], pageUtil['pageSize'], pageUtil['currentPage'])}></button>
                <button className="btn-paging last" type="button" title="마지막 페이지" onClick={() => this.setCurrentPage('LAST', pageUtil['recordCount'], pageUtil['pageSize'], pageUtil['currentPage'])}></button>
            </div>
            <select className="pageSize" onChange={(e)=> this.setPagesize(e)}>
                <option value="10">10</option>
                <option value="20">20</option>
                <option value="30">30</option>
                <option value="40">40</option>
                <option value="50">50</option>
            </select>
        </div>
        )
    }
}


export default connect((state) => {
    return {
        pageUtil : state
    };
}, (dispatch) => {
    return {
        setCurrentPage(currentPage) {
            dispatch({type:'SET_CURPAGE', currentPage: currentPage});
        },
        setPagesize(size) {
            dispatch({type:'SET_PAGESIZE', pageSize: size});
        }
    }; 
})(Pagination);