import { act } from 'react-dom/test-utils';
import {createStore} from 'redux';

const initState = {
        blockSize: 10,
        currentPage: 1,
        lastPage: 9,
        maxRows: 10,
        pageSize: 10,
        recordCount: 81,
        rowBounds: {offset: 0, limit: 10},
        skipRows: 0
}

function reducer(state = initState, action) {
    
    if(action['type'] === 'SET_CURPAGE') {
        console.log(action.currentPage)
        return {...state,  currentPage: action.currentPage};
    }

    if(action['type'] === 'SET_PAGESIZE') {
        console.log(action.pageSize);
        return {...state, pageSize: action.pageSize};
    }
    
    return state;
}

export default createStore(reducer);